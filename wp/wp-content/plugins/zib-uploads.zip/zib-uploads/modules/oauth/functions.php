<?php
/**
 * 社交登录功能 - Google & MixAuth QQ登录
 * 完全基于子比主题的官方机制实现
 */

// 安全检测
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 独立插件社交登录实现
 * 
 * 策略：利用子主题已有的Google和MixAuth QQ支持
 * 通过配置桥接让插件的设置被子主题识别
 * 这样无论有没有子主题都能工作
 */

/**
 * 检查插件社交登录功能是否启用
 */
function zibll_plugin_social_login_enabled() {
    if (!function_exists('zibll_plugin_option')) {
        return false;
    }
    
    return zibll_plugin_option('google_enable', false) || zibll_plugin_option('mixauth_qq_enable', false);
}

/**
 * 配置桥接：让插件设置被主题/子主题识别
 * 
 * 1. 如果有子主题，通过 option_mrhe_options 过滤器桥接到 _mrhe() 函数
 * 2. 如果只有父主题，通过 JavaScript 动态添加按钮
 */

// 桥接到子主题配置（如果子主题存在）
add_filter('option_mrhe_options', 'zibll_plugin_bridge_mrhe_options');

function zibll_plugin_bridge_mrhe_options($options) {
    if (!is_array($options)) {
        $options = array();
    }
    
    // 只有在插件功能启用时才桥接
    if (function_exists('zibll_plugin_option')) {
        // Google 登录配置桥接
        if (zibll_plugin_option('google_enable', false)) {
            $options['oauth_google_s'] = true;
            $options['oauth_google_option'] = zibll_plugin_get_google_config();
        }
        
        // MixAuth QQ 登录配置桥接
        if (zibll_plugin_option('mixauth_qq_enable', false)) {
            $options['oauth_mixauthqq_s'] = true;
            $options['oauth_mixauthqq_option'] = zibll_plugin_get_mixauth_config();
        }
    }
    
    return $options;
}

/**
 * 为没有子主题的情况提供回退方案
 * 检测是否有子主题，如果没有则使用JavaScript添加按钮
 */
function zibll_plugin_add_fallback_buttons() {
    // 检查插件功能是否启用
    if (!zibll_plugin_social_login_enabled()) {
        return;
    }
    
    // 检查是否已经有子主题的支持
    $child_theme = get_stylesheet_directory() !== get_template_directory();
    $has_child_support = $child_theme && function_exists('_mrhe');
    
    // 如果有子主题支持，就不需要回退方案
    if ($has_child_support) {
        return;
    }
    
    // 使用JavaScript在前端添加按钮
    add_action('wp_footer', function() {
        ?>
        <script>
        jQuery(document).ready(function($) {
            // 查找社交登录容器
            var $socialContainer = $('.social_loginbar');
            if ($socialContainer.length > 0) {
                var ourButtons = '';
                
                <?php if (zibll_plugin_option('google_enable', false)): ?>
                    <?php $config = zibll_plugin_get_google_config(); ?>
                    <?php if ($config['client_id'] && $config['client_secret']): ?>
                        var googleButton = '<a rel="nofollow" title="Google登录" href="<?php echo esc_url(home_url('/oauth/google')); ?>" class="social-login-item google toggle-radius"><i class="fa fa-google"></i></a>';
                        ourButtons += googleButton;
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if (zibll_plugin_option('mixauth_qq_enable', false)): ?>
                    <?php $config = zibll_plugin_get_mixauth_config(); ?>
                    <?php if ($config['server_url']): ?>
                        var mixauthButton = '<a rel="nofollow" title="MixAuth QQ登录" href="<?php echo esc_url(home_url('/oauth/mixauthqq')); ?>" class="social-login-item mixauthqq toggle-radius"><i class="fa fa-qq"></i></a>';
                        ourButtons += mixauthButton;
                    <?php endif; ?>
                <?php endif; ?>
                
                if (ourButtons) {
                    $socialContainer.append(ourButtons);
                }
            }
        });
        </script>
        <?php
    }, 999);
}

// 启用回退方案
add_action('wp_head', 'zibll_plugin_add_fallback_buttons');

/**
 * AJAX处理函数：代理MixAuth状态检查请求
 * 由于CORS限制，前端无法直接访问MixAuth API，需要后端代理
 */
function zibll_plugin_mixauth_qq_ajax_check_status() {
    // 检查插件功能是否启用
    if (!zibll_plugin_option('mixauth_qq_enable', false)) {
        http_response_code(403);
        echo json_encode(['error' => 'MixAuth QQ功能未启用']);
        wp_die();
    }
    
    // 设置JSON响应头
    header('Content-Type: application/json');
    
    // 验证nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mixauthqq_status')) {
        http_response_code(403);
        echo json_encode(['error' => '安全验证失败']);
        wp_die();
    }
    
    // 验证必要参数
    if (!isset($_POST['server_url']) || !isset($_POST['qr_id'])) {
        http_response_code(400);
        echo json_encode(['error' => '缺少必要参数']);
        wp_die();
    }
    
    // 清理和验证输入
    $server_url = esc_url_raw($_POST['server_url']);
    $qr_id = sanitize_text_field($_POST['qr_id']);
    
    if (empty($server_url) || empty($qr_id)) {
        http_response_code(400);
        echo json_encode(['error' => '参数格式错误']);
        wp_die();
    }
    
    // 构建请求到MixAuth API
    $api_url = rtrim($server_url, '/') . '/api/status';
    $request_body = json_encode([
        'type' => 'qq',
        'id' => $qr_id
    ]);
    
    // 发送请求到MixAuth
    $response = wp_remote_post($api_url, [
        'body' => $request_body,
        'headers' => [
            'Content-Type' => 'application/json',
        ],
        'timeout' => 15,
        'user-agent' => 'WordPress-Plugin/1.0'
    ]);
    
    // 检查请求是否成功
    if (is_wp_error($response)) {
        error_log('MixAuth API Error: ' . $response->get_error_message());
        http_response_code(500);
        echo json_encode(['error' => '网络请求失败: ' . $response->get_error_message()]);
        wp_die();
    }
    
    // 获取响应代码和内容
    $response_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    
    // 设置相应的HTTP状态码
    http_response_code($response_code);
    
    // 直接返回MixAuth的响应
    echo $body;
    wp_die();
}

// 注册AJAX处理函数（登录和未登录用户都可以访问）
add_action('wp_ajax_mixauthqq_check_status', 'zibll_plugin_mixauth_qq_ajax_check_status');
add_action('wp_ajax_nopriv_mixauthqq_check_status', 'zibll_plugin_mixauth_qq_ajax_check_status');

/**
 * 为社交登录类型提供登录URL
 */
function zibll_plugin_oauth_login_url($url, $type) {
    // 检查插件功能是否启用
    if (!zibll_plugin_social_login_enabled()) {
        return $url;
    }
    
    // Google 登录URL
    if ($type === 'google' && !$url && zibll_plugin_option('google_enable', false)) {
        $config = zibll_plugin_get_google_config();
        if ($config['client_id'] && $config['client_secret']) {
            return home_url('/oauth/google');
        }
    }
    
    // MixAuth QQ 登录URL
    if ($type === 'mixauthqq' && !$url && zibll_plugin_option('mixauth_qq_enable', false)) {
        $config = zibll_plugin_get_mixauth_config();
        if ($config['server_url']) {
            return home_url('/oauth/mixauthqq');
        }
    }
    
    return $url;
}
add_filter('zib_oauth_login_url', 'zibll_plugin_oauth_login_url', 40, 2);

/**
 * 注册OAuth路由重写规则
 */
function zibll_plugin_oauth_rewrite_rules($wp_rewrite) {
    // 检查插件功能是否启用
    if (!zibll_plugin_social_login_enabled()) {
        return;
    }
    
    if ($ps = get_option('permalink_structure')) {
        // 添加我们的OAuth路由到现有规则中
        $new_rules = $wp_rewrite->rules;
        
        // 如果还没有oauth规则，添加它们
        if (!isset($new_rules['oauth/([A-Za-z_]+)$'])) {
            $new_rules['oauth/([A-Za-z_]+)$'] = 'index.php?oauth=$matches[1]';
            $new_rules['oauth/([A-Za-z_]+)/callback$'] = 'index.php?oauth=$matches[1]&oauth_callback=1';
        }
        
        $wp_rewrite->rules = $new_rules;
    }
}
add_action('generate_rewrite_rules', 'zibll_plugin_oauth_rewrite_rules', 5);

/**
 * 处理OAuth模板路由
 */
function zibll_plugin_oauth_template() {
    $oauth = strtolower(get_query_var('oauth'));
    $oauth_callback = get_query_var('oauth_callback');
    
    if ($oauth && in_array($oauth, array('google', 'mixauthqq'))) {
        // 检查插件功能是否启用
        if (!zibll_plugin_social_login_enabled()) {
            // 如果插件功能未启用，不拦截路由，让子主题处理
            return;
        }
        
        // 检查具体类型是否启用
        if ($oauth === 'google' && !zibll_plugin_option('google_enable', false)) {
            return;
        }
        if ($oauth === 'mixauthqq' && !zibll_plugin_option('mixauth_qq_enable', false)) {
            return;
        }
        
        global $wp_query;
        $wp_query->is_home = false;
        $wp_query->is_page = false;
        
        // 确定模板文件路径
        $template_file = $oauth_callback ? '/callback.php' : '/login.php';
        $template_path = plugin_dir_path(__FILE__) . 'oauth/' . $oauth . $template_file;
        
        if (file_exists($template_path)) {
            load_template($template_path);
            exit;
        } else {
            // 回退到404
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            return;
        }
    }
}
add_action('template_redirect', 'zibll_plugin_oauth_template', 1);

/**
 * 获取 Google OAuth 配置
 */
function zibll_plugin_get_google_config() {
    $defaults = array(
        'client_id'     => '',
        'client_secret' => '',
        'redirect_uri'  => home_url('/oauth/google/callback'),
    );
    
    $options = get_option('zibll_plugin_option_options', array());
    $config = array(
        'client_id'     => isset($options['google_client_id']) ? $options['google_client_id'] : '',
        'client_secret' => isset($options['google_client_secret']) ? $options['google_client_secret'] : '',
        'redirect_uri'  => $defaults['redirect_uri'],
    );
    
    return wp_parse_args($config, $defaults);
}

/**
 * 获取 MixAuth QQ 配置
 */
function zibll_plugin_get_mixauth_config() {
    $defaults = array(
        'server_url'        => 'https://mixauthqq.vercel.app',
        'integration_mode'  => 'api',
        'redirect_uri'      => home_url('/oauth/mixauthqq/callback'),
    );
    
    $options = get_option('zibll_plugin_option_options', array());
    $config = array(
        'server_url'        => isset($options['mixauth_qq_server_url']) ? $options['mixauth_qq_server_url'] : $defaults['server_url'],
        'integration_mode'  => isset($options['mixauth_qq_integration_mode']) ? $options['mixauth_qq_integration_mode'] : $defaults['integration_mode'],
        'redirect_uri'      => $defaults['redirect_uri'],
    );
    
    return wp_parse_args($config, $defaults);
}

/**
 * AJAX处理：MixAuth状态检查代理
 */
function zibll_plugin_mixauth_status_ajax() {
    // 检查插件功能是否启用
    if (!zibll_plugin_option('mixauth_qq_enable', false)) {
        http_response_code(403);
        echo json_encode(['error' => 'MixAuth QQ功能未启用']);
        wp_die();
    }
    
    header('Content-Type: application/json');
    
    // 验证nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mixauth_status')) {
        http_response_code(403);
        echo json_encode(['error' => '安全验证失败']);
        wp_die();
    }
    
    $server_url = isset($_POST['server_url']) ? sanitize_url($_POST['server_url']) : '';
    $qr_id = isset($_POST['qr_id']) ? sanitize_text_field($_POST['qr_id']) : '';
    
    // 参数验证
    if (!filter_var($server_url, FILTER_VALIDATE_URL) || !preg_match('/^[a-zA-Z0-9]+$/', $qr_id)) {
        http_response_code(400);
        echo json_encode(['error' => '参数无效']);
        wp_die();
    }
    
    // 发送请求到MixAuth服务
    $response = wp_remote_post($server_url . '/api/status', array(
        'body' => json_encode(array(
            'type' => 'qq',
            'id' => $qr_id
        )),
        'headers' => array(
            'Content-Type' => 'application/json',
            'User-Agent' => 'WordPress/' . get_bloginfo('version') . '; ' . home_url(),
        ),
        'timeout' => 10,
        'sslverify' => false,
    ));
    
    if (is_wp_error($response)) {
        http_response_code(500);
        echo json_encode(['error' => 'MixAuth服务请求失败']);
        wp_die();
    }
    
    $body = wp_remote_retrieve_body($response);
    $http_code = wp_remote_retrieve_response_code($response);
    
    // 验证JSON
    json_decode($body);
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(502);
        echo json_encode(['error' => 'MixAuth服务返回无效数据']);
        wp_die();
    }
    
    http_response_code($http_code);
    echo $body;
    wp_die();
}
add_action('wp_ajax_mixauth_status', 'zibll_plugin_mixauth_status_ajax');
add_action('wp_ajax_nopriv_mixauth_status', 'zibll_plugin_mixauth_status_ajax');

/**
 * 添加用户中心OAuth绑定支持
 */
function zibll_plugin_add_oauth_binding($html, $user_id) {
    if (!$user_id) {
        return $html;
    }
    
    // 检查插件功能是否启用
    if (!zibll_plugin_social_login_enabled()) {
        return $html;
    }
    
    $added_html = '';
    
    // Google登录绑定
    if (zibll_plugin_option('google_enable', false)) {
        $added_html .= zibll_plugin_generate_oauth_binding_html($user_id, 'google', 'Google', 'fa fa-google');
    }
    
    // MixAuth QQ登录绑定
    if (zibll_plugin_option('mixauth_qq_enable', false)) {
        $added_html .= zibll_plugin_generate_oauth_binding_html($user_id, 'mixauthqq', 'MixAuth QQ', 'fa fa-qq');
    }
    
    if ($added_html) {
        // 尝试多种插入策略，确保兼容性
        $inserted = false;
        
        // 策略1：在OAuth设置部分插入
        $pos = strpos($html, 'class="box-body oauth-set"');
        if ($pos !== false) {
            $pos = strpos($html, 'class="flex hh oauth-bind-box gutters-5"', $pos);
            if ($pos !== false) {
                $pos = strpos($html, '>', $pos) + 1;
                $html = substr($html, 0, $pos) . $added_html . substr($html, $pos);
                $inserted = true;
            }
        }
        
        // 策略2：如果没有找到OAuth设置区域，寻找其他可能的位置
        if (!$inserted) {
            // 寻找任何含有oauth字样的容器
            $pos = strpos($html, 'oauth');
            if ($pos !== false) {
                // 寻找最近的容器结束位置
                $container_end = strpos($html, '</div>', $pos);
                if ($container_end !== false) {
                    $html = substr($html, 0, $container_end) . 
                           '<div class="oauth-bind-box gutters-5">' . $added_html . '</div>' . 
                           substr($html, $container_end);
                    $inserted = true;
                }
            }
        }
        
        // 策略3：如果仍然无法插入，直接附加到HTML末尾
        if (!$inserted) {
            $html .= '<div class="box mt20"><div class="box-body"><h4>插件社交登录</h4>' . 
                    '<div class="oauth-bind-box gutters-5">' . $added_html . '</div></div></div>';
        }
    }
    
    return $html;
}
add_filter('user_center_account_setup', 'zibll_plugin_add_oauth_binding', 10, 2);

/**
 * 生成OAuth绑定HTML
 */
function zibll_plugin_generate_oauth_binding_html($user_id, $type, $name, $icon) {
    $rurl = function_exists('zib_get_user_center_url') ? zib_get_user_center_url('account') : home_url();
    $bind_href = function_exists('zib_get_oauth_login_url') ? 
        zib_get_oauth_login_url($type, $rurl) : 
        home_url('/oauth/' . $type);
    
    if (!$bind_href) {
        return '';
    }
    
    $bind_href = add_query_arg('bind', $type, $bind_href);
    
    // 兼容性检查：确保在所有环境下都能正确读取绑定状态
    $oauth_info = null;
    $oauth_id = get_user_meta($user_id, 'oauth_' . $type . '_openid', true);
    
    // 首先尝试使用主题的用户元数据函数
    if (function_exists('zib_get_user_meta')) {
        $oauth_info = zib_get_user_meta($user_id, 'oauth_' . $type . '_getUserInfo', true);
    }
    
    // 如果主题函数没有返回数据，尝试直接从用户元数据表读取
    if (!$oauth_info) {
        $oauth_info = get_user_meta($user_id, 'oauth_' . $type . '_getUserInfo', true);
    }
    
    // 如果还是没有数据，但是有openid，可能是数据存储位置不同
    // 在这种情况下，我们创建基本的绑定信息显示
    if (!$oauth_info && $oauth_id) {
        $oauth_info = array(
            'name' => $name,
            'avatar' => ''
        );
    }
    
    // 调试：记录获取到的数据
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log("Plugin OAuth Binding Check - Type: {$type}, User: {$user_id}, Info: " . 
                 (is_array($oauth_info) ? json_encode($oauth_info) : var_export($oauth_info, true)) . 
                 ", ID: {$oauth_id}");
    }
    
    if ($oauth_info && $oauth_id) {
        // 已绑定状态
        $user_name = !empty($oauth_info['name']) ? esc_attr($oauth_info['name']) : $name . '账号';
        $user_avatar = !empty($oauth_info['avatar']) ? $oauth_info['avatar'] : '';
        $avatar_html = '';
        
        if ($user_avatar && function_exists('zib_get_lazy_attr')) {
            $lazy_attr = zib_get_lazy_attr('lazy_avatar', $user_avatar, 'avatar', ZIB_TEMPLATE_DIRECTORY_URI . '/img/thumbnail-null.svg');
            $avatar_html = '<span class="avatar-img avatar-sm mr6" style="--this-size: 22px;"><img ' . $lazy_attr . ' alt="' . $name . '头像"></span>';
        }
        
        $desc = $avatar_html ? $avatar_html . $user_name : $user_name;
        $desc = '<div class="muted-2-color text-ellipsis mr10 ml20" data-toggle="tooltip" title="已绑定' . $name . '账号">' . $desc . '</div>';
        $btn = '<a data-toggle="tooltip" href="javascript:;" openid="' . esc_attr($oauth_id) . '" title="解绑' . $name . '账号" user-id="' . $user_id . '" untying-type="' . $type . '" class="em09 p2-10 oauth-untying but hollow c-yellow">解绑</a>';
    } else {
        // 未绑定状态
        $desc = '<div class="muted-2-color">暂未绑定</div>';
        $btn = '<a title="绑定' . $name . '账号" href="' . esc_url($bind_href) . '" class="em09 p2-10 but hollow c-blue">绑定</a>';
    }
    
    $html = '<div class="mb10"><div class="flex ac jsb muted-box">';
    $html .= '<div class="flex ac type-logo"><span class="social-login-item circular mr6 em12 ' . $type . '"><i class="' . $icon . '" aria-hidden="true"></i></span><span class="">' . $name . '</span></div>';
    $html .= '<div class="overflow-hidden">' . $desc . '</div>';
    $html .= '<div class="shrink0">' . $btn . '</div>';
    $html .= '</div></div>';
    
    return $html;
}

/**
 * 处理OAuth解绑请求
 */
function zibll_plugin_handle_oauth_untying() {
    if (empty($_POST['user_id']) || empty($_POST['type'])) {
        return; // 让其他处理函数继续
    }
    
    $type = $_POST['type'];
    
    // 只处理我们支持的OAuth类型
    if (!in_array($type, array('google', 'mixauthqq'))) {
        return; // 让其他处理函数继续
    }
    
    // 检查插件功能是否启用
    if (!zibll_plugin_social_login_enabled()) {
        return; // 让其他处理函数继续
    }
    
    $user_id = (int)$_POST['user_id'];
    $current_user_id = get_current_user_id();
    
    // 安全检查
    if (!$current_user_id || $current_user_id != $user_id) {
        wp_send_json_error(array('msg' => '权限不足', 'ys' => 'danger'));
        exit;
    }
    
    // 删除绑定信息
    delete_user_meta($user_id, 'oauth_' . $type . '_openid');
    if (function_exists('zib_update_user_meta')) {
        zib_update_user_meta($user_id, 'oauth_' . $type . '_getUserInfo', false);
    } else {
        delete_user_meta($user_id, 'oauth_' . $type . '_getUserInfo');
    }
    
    // 返回成功结果
    $goto = function_exists('zib_get_user_center_url') ? zib_get_user_center_url('account') : home_url();
    $type_name = $type === 'google' ? 'Google' : 'MixAuth QQ';
    wp_send_json(array(
        'error' => 0,
        'msg' => '已解除' . $type_name . '绑定',
        'ys' => 'success',
        'reload' => true,
        'goto' => $goto
    ));
    exit;
}
add_action('wp_ajax_user_oauth_untying', 'zibll_plugin_handle_oauth_untying', 5);