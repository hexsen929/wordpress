<?php

$prefix = 'zibll_plugin_option';

CSF::createOptions($prefix, array(
    'menu_title' => '子比主题·功能增强插件',
    'menu_slug' => 'zibll_plugin_option',
    'framework_title' => '子比主题·功能增强插件 <small>v2.0</small>',
    'show_in_customizer' => true,
    'footer_text' => '由何先生开发的子比主题·功能增强插件',
    'footer_credit' => '<i class="fa fa-heart" style="color:#ff4757"></i> 感谢使用',
    'theme' => 'light'
));

// 前端附件管理设置
CSF::createSection($prefix, array(
    'id'      => 'attachment',
    'title'       => '前端附件管理',
    'icon'        => 'fa fa-fw fa-file-image-o',
    'description' => '前端附件管理设置，包括用户中心和作者相册',
    'fields'      => array(
        array(
            'title'    => '单页加载数量',
            'id'       => 'img_list_number',
            'default'  => 16,
            'type'     => 'spinner',
            'step'     => 4,
            'unit'     => '张',
        ),
        array(
            'id'      => 'paging_ajax_s',
            'title'   => '列表翻页模式',
            'default' => '1',
            'type'    => "radio",
            'inline'  => true,
            'desc'    => '您可以在上面选项，以调整单页加载数量',
            'options' => array(
                '1' => __('AJAX追加列表翻页', 'zib_language'),
                '0' => __('数字翻页按钮', 'zib_language'),
            ),
        ),
        array(
            'title'    => '允许用户删除附件',
            'subtitle' => '',
            'id'       => 'user_delete_image',
            'type'     => "switcher",
            'default'  => true,
        ),
        array(
            'title'    => '启用作者个人相册',
            'subtitle' => '控制作者主页"个人相册"标签是否显示',
            'id'       => 'author_album_enable',
            'type'     => 'switcher',
            'default'  => true,
        ),
        array(
            'title'    => '作者相册显示类别',
            'subtitle' => '选择非管理员在作者主页相册中显示的文件类型',
            'id'       => 'author_album_type',
            'type'     => 'radio',
            'inline'   => true,
            'default'  => 'image_video',
            'options'  => array(
                'image'       => '图片',
                'video'       => '视频',
                'image_video' => '图片和视频',
            ),
        ),
    )
));

// 核心功能设置
CSF::createSection($prefix, array(
    'id' => 'core_settings',
    'title' => '核心功能',
    'icon' => 'fa fa-cube',
    'fields' => array(
        array(
            'id' => 'prohibited_balance_pay_types',
            'type' => 'checkbox',
            'title' => '禁止使用余额支付的类型',
            'subtitle' => '勾选不允许使用余额支付的场景',
            'options' => array(
                '1' => '付费阅读',
                '2' => '付费资源',
                '3' => '产品购买',
                '4' => '购买会员',
                '5' => '付费图片',
                '6' => '付费视频',
                '7' => '自动售卡',
                '8' => '余额充值',
                '9' => '购买积分',
            ),
            'default' => array('8'),
            'help' => '防止用户用余额购买余额的套娃行为',
        ),
        array(
            'type' => 'submessage',
            'style' => 'danger',
            'content' => '<div style="padding:10px;background:#fff8f8;border-left:3px solid #ff4757">
                <b>⚠️ 注意</b>
                <p>你已禁止使用余额进行余额充值，这是明智的选择！</p>
                <p>否则用户可以用余额购买余额，形成无限套娃...</p>
            </div>',
            'dependency' => array('prohibited_balance_pay_types', '==', '8'),
        ),
        array(
            'id' => 'show_copyright',
            'type' => 'switcher',
            'title' => '文章版权信息',
            'label' => '在文章底部显示版权信息',
            'default' => false,
        ),
        array(
            'id' => 'copyright_text',
            'type' => 'text',
            'title' => '版权文字内容',
            'dependency' => array('show_copyright', '==', '1'),
            'default' => '本文来自子比主题演示插件',
            'placeholder' => '输入要显示的版权信息',
            'validate' => 'wp_kses_post',
        ),
    )
));

// 外观设置
CSF::createSection($prefix, array(
    'id' => 'appearance',
    'title' => '外观设置',
    'icon' => 'fa fa-paint-brush',
    'fields' => array(
        array(
            'id' => 'site_greyscale',
            'type' => 'switcher',
            'title' => '全站变灰模式',
            'label' => '特殊日期开启全站灰色效果',
            'default' => false,
            'help' => '适用于纪念日等特殊场景',
        ),
        array(
            'id' => 'admin_css',
            'type' => 'code_editor',
            'title' => '后台自定义CSS',
            'subtitle' => '修改WordPress后台样式',
            'settings' => array(
                'theme' => 'dracula',
                'mode' => 'css',
                'tabSize' => 4,
            ),
            'default' => '/* 在这里添加CSS代码 */',
            'sanitize' => 'wp_strip_all_tags',
        ),
        array(
            'type' => 'submessage',
            'style' => 'warning',
            'content' => '<div style="padding:10px;background:#fff8e1;border-left:3px solid #ffc107">
                <b><i class="fa fa-exclamation-triangle"></i> 重要提示</b>
                <p>1. 修改前建议备份当前CSS</p>
                <p>2. 错误的CSS可能导致后台显示异常</p>
            </div>',
            'dependency' => array('admin_css', '!=', ''),
        ),
    )
));

// 多语言翻译设置
CSF::createSection($prefix, array(
    'id' => 'translation_settings',
    'title' => '多语言翻译',
    'icon' => 'fa fa-language',
    'description' => '网站多语言翻译功能，支持实时页面翻译和多种翻译服务',
    'fields' => array(
        array(
            'type' => 'submessage',
            'style' => 'warning',
            'content' => '<div style="padding:15px;background:#d4edda;border-left:4px solid #28a745;border-radius:4px;">
                <h4><i class="fa fa-check-circle" style="color:#155724;"></i> 智能兼容说明</h4>
                <p style="margin:10px 0;color:#155724;"><strong>插件已优化兼容性处理，支持以下使用场景：</strong></p>
                <ul style="margin:10px 0 10px 20px;color:#155724;">
                    <li><strong>独立使用</strong>：插件单独启用，子主题翻译功能关闭（推荐）</li>
                    <li><strong>智能检测</strong>：插件会自动检测子主题状态，避免冲突</li>
                    <li><strong>按需输出</strong>：只有启用插件翻译时才输出配置，干净整洁</li>
                    <li><strong>无缝切换</strong>：可随时在子主题和插件间切换，无副作用</li>
                </ul>
                <p style="margin:10px 0;color:#155724;font-size:12px;"><em>✨ 现在您可以放心启用，插件已完美处理所有兼容性问题！</em></p>
            </div>',
        ),
        array(
            'id' => 'translation_enabled',
            'type' => 'switcher',
            'title' => '启用翻译功能',
            'label' => '开启网站多语言翻译功能',
            'desc' => '启用后将在网站头部或浮动按钮中显示语言切换器，并自动覆盖子主题的翻译配置',
            'default' => false,
        ),
        array(
            'id' => 'translation_service',
            'type' => 'radio',
            'title' => '翻译服务选择',
            'options' => array(
                'client.edge' => 'Microsoft Edge（推荐）- 直接调用微软翻译，无字符限制',
                'translate.service' => 'translate.service - 默认翻译服务，200万字符/日',
            ),
            'default' => 'client.edge',
            'desc' => '根据官方文档，推荐使用 client.edge 模式，更稳定且无字符数限制',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_enabled_languages',
            'type' => 'checkbox',
            'title' => '启用的语言',
            'subtitle' => '选择要在语言切换器中显示的语言',
            'options' => array(
                'chinese_simplified' => '简体中文 🇨🇳',
                'chinese_traditional' => '繁體中文 🇹🇼',
                'english' => 'English 🇺🇸',
                'japanese' => '日本語 🇯🇵',
                'korean' => '한국어 🇰🇷',
                'vietnamese' => 'Vietnamese 🇻🇳',
                'russian' => 'Русский 🇷🇺',
                'spanish' => 'Español 🇪🇸',
                'french' => 'Français 🇫🇷',
                'deutsch' => 'Deutsch 🇩🇪',
                'portuguese' => 'Português 🇧🇷',
                'thai' => 'ไทย 🇹🇭',
                'hindi' => 'हिन्दी 🇮🇳',
                'arabic' => 'العربية 🇸🇦',
            ),
            'default' => array('chinese_simplified', 'english'),
            'desc' => '建议不要启用过多语言，以免影响用户体验',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_default_lang',
            'type' => 'select',
            'title' => '默认语言',
            'subtitle' => '网站的默认显示语言',
            'options' => array(
                'chinese_simplified' => '简体中文',
                'chinese_traditional' => '繁體中文',
                'english' => 'English',
                'japanese' => '日本語',
                'korean' => '한국어',
                'vietnamese' => 'Vietnamese',
                'russian' => 'Русский',
                'spanish' => 'Español',
                'french' => 'Français',
                'deutsch' => 'Deutsch',
                'portuguese' => 'Português',
                'thai' => 'ไทย',
                'hindi' => 'हिन्दी',
                'arabic' => 'العربية',
            ),
            'default' => 'chinese_simplified',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_auto_detect',
            'type' => 'switcher',
            'title' => '自动检测语言',
            'label' => '根据浏览器语言自动选择翻译语言',
            'desc' => '开启后会根据用户浏览器语言自动判断显示语言',
            'default' => true,
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translate_js',
            'type' => 'switcher',
            'title' => '页面元素动态监控',
            'desc' => '开启页面元素动态监控，js改变的内容也会被翻译',
            'default' => false,
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_button_position',
            'type' => 'radio',
            'title' => '按钮显示位置',
            'options' => array(
                'header' => '导航栏 - 显示在网站顶部导航栏',
                'footer' => '悬浮按钮 - 显示为右侧悬浮按钮（推荐）',
                'both' => '同时显示 - 导航栏和悬浮按钮都显示',
            ),
            'default' => 'footer',
            'desc' => '悬浮按钮样式更美观，不占用导航栏空间',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        // 翻译忽略设置
        array(
            'type' => 'subheading',
            'content' => '翻译忽略设置',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'type' => 'submessage',
            'style' => 'info',
            'content' => '<div style="padding:10px;background:#f0f8ff;border-left:3px solid #007cba">
                <b><i class="fa fa-info-circle"></i> 忽略功能说明</b>
                <p>• translate.js 默认已忽略 class="ignore" 的元素</p>
                <p>• 可以通过下方设置自定义更多忽略规则</p>
                <p>• 合理设置忽略规则可以提高翻译精度和性能</p>
            </div>',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_ignore_tags',
            'type' => 'text',
            'title' => '忽略HTML标签',
            'subtitle' => '不翻译指定的HTML标签内容',
            'desc' => '多个标签用英文逗号分隔，如：script,style,code',
            'placeholder' => 'script,style,code',
            'default' => 'code,pre,script,style',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_ignore_classes',
            'type' => 'text',
            'title' => '忽略CSS类名',
            'subtitle' => '不翻译指定class的元素内容',
            'desc' => '多个class用英文逗号分隔（注：ignore类默认已忽略，无需重复设置）',
            'placeholder' => 'no-translate,code-block',
            'default' => 'no-translate',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_ignore_ids',
            'type' => 'text',
            'title' => '忽略元素ID',
            'subtitle' => '不翻译指定id的元素内容',
            'desc' => '多个ID用英文逗号分隔，如：header,footer,sidebar',
            'placeholder' => 'header,footer,sidebar',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_ignore_texts',
            'type' => 'textarea',
            'title' => '忽略指定文本',
            'subtitle' => '不翻译包含特定文本的内容',
            'desc' => '每行一个文本，支持精确匹配',
            'placeholder' => '版权所有©' . "\n" . 'All Rights Reserved' . "\n" . 'TODO:',
            'attributes' => array(
                'rows' => 5,
            ),
            'dependency' => array('translation_enabled', '==', '1'),
        ),
        array(
            'id' => 'translation_ignore_regexs',
            'type' => 'textarea',
            'title' => '正则表达式忽略',
            'subtitle' => '使用正则表达式匹配不需要翻译的内容',
            'desc' => '每行一个正则表达式，无需添加斜杠和修饰符，系统会自动处理',
            'placeholder' => 'TODO:' . "\n" . '\\d{4}-\\d{2}-\\d{2}' . "\n" . '@\\w+' . "\n" . '#\\w+',
            'default' => 'TODO:\n\\d{4}-\\d{2}-\\d{2}\n@\\w+\n#\\w+',
            'attributes' => array(
                'rows' => 6,
            ),
            'subtitle' => '常用示例：TODO: (匹配TODO开头)、\\d{4}-\\d{2}-\\d{2} (匹配日期)、@\\w+ (匹配@用户名)、#\\w+ (匹配#标签)',
            'dependency' => array('translation_enabled', '==', '1'),
        ),
    )
));

// 会员权限管理
CSF::createSection($prefix, array(
    'id' => 'vip_settings',
    'title' => '会员权限管理',
    'icon' => 'fa fa-crown',
    'description' => '会员特权功能设置，可单独控制不同级别会员的权限',
    'fields' => array(
        array(
            'id' => 'vip1_skip_comment_view',
            'type' => 'switcher',
            'title' => '一级会员免评论查看',
            'label' => '启用一级会员免评论查看功能',
            'desc' => '开启后，一级会员用户无需评论即可查看"评论可见"的内容',
            'default' => false,
        ),
        array(
            'id' => 'vip2_skip_comment_view',
            'type' => 'switcher',
            'title' => '二级会员免评论查看',
            'label' => '启用二级会员免评论查看功能',
            'desc' => '开启后，二级会员用户无需评论即可查看"评论可见"的内容<br><span style="color:#f97113;">此功能会让会员用户拥有与管理员相同的查看权限，请谨慎开启</span>',
            'default' => false,
        ),
        array(
            'type' => 'submessage',
            'style' => 'info',
            'content' => '<div style="padding:10px;background:#f0f8ff;border-left:3px solid #007cba">
                <b><i class="fa fa-info-circle"></i> 功能说明</b>
                <p>• 此功能需要配合子比主题的VIP系统使用</p>
                <p>• 会员等级判断基于子比主题的会员系统</p>
                <p>• 开启后对应等级的会员可以直接查看评论可见内容</p>
            </div>',
            'dependency' => array(
                array('vip1_skip_comment_view', '==', '1'),
                array('vip2_skip_comment_view', '==', '1'),
            ),
        ),
    )
));

// Google 登录设置
CSF::createSection($prefix, array(
    'title' => 'Google 登录',
    'icon' => 'fa fa-google',
    'fields' => array(
        array(
            'id' => 'google_enable',
            'type' => 'switcher',
            'title' => '启用 Google 登录',
            'desc' => '基于 Google OAuth 2.0 的官方登录功能',
            'default' => false,
        ),
        array(
            'id' => 'google_client_id',
            'type' => 'text',
            'title' => 'Google Client ID',
            'desc' => '从 Google Cloud Console 获取的客户端ID',
            'dependency' => array('google_enable', '==', 'true'),
        ),
        array(
            'id' => 'google_client_secret',
            'type' => 'text',
            'title' => 'Google Client Secret',
            'desc' => '从 Google Cloud Console 获取的客户端密钥',
            'dependency' => array('google_enable', '==', 'true'),
        ),
        array(
            'type' => 'submessage',
            'style' => 'info',
            'content' => '<h4><b>Google OAuth 配置步骤：</b></h4>
                <p>1. <strong>回调地址：</strong>' . home_url('/oauth/google/callback') . '</p>
                <p>2. 访问 <a target="_blank" href="https://console.cloud.google.com/">Google Cloud Console</a></p>
                <p>3. 创建新项目或选择现有项目</p>
                <p>4. 启用 Google+ API 或 People API</p>
                <p>5. 创建 OAuth 2.0 客户端ID</p>
                <p>6. 设置重定向URI为上方显示的回调地址</p>
                <p>7. 将获取的 Client ID 和 Client Secret 填入上方设置</p>',
            'dependency' => array('google_enable', '==', 'true'),
        ),
    )
));

// MixAuth QQ登录设置
CSF::createSection($prefix, array(
    'title' => 'MixAuth QQ登录',
    'icon' => 'fa fa-qq',
    'fields' => array(
        array(
            'id' => 'mixauth_qq_enable',
            'type' => 'switcher',
            'title' => '启用MixAuth QQ登录',
            'desc' => '基于MixAuth项目的第三方QQ登录功能，无需申请QQ互联应用',
            'default' => false,
        ),
        array(
            'id' => 'mixauth_qq_server_url',
            'type' => 'text',
            'title' => 'MixAuth服务地址',
            'desc' => '输入MixAuth服务的完整URL，如：https://mixauth.onrender.com 或您自己部署的地址',
            'default' => 'https://mixauth.onrender.com',
            'dependency' => array('mixauth_qq_enable', '==', 'true'),
        ),
        array(
            'id' => 'mixauth_qq_integration_mode',
            'type' => 'radio',
            'title' => '接入方式',
            'options' => array(
                'api' => 'API接口模式（推荐）- 自定义UI，支持纯QQ登录',
                'iframe' => 'iframe嵌入模式 - 使用MixAuth完整页面'
            ),
            'default' => 'api',
            'desc' => 'API模式：自定义二维码UI，更快速，支持纯QQ登录，支持签名验证<br>iframe模式：嵌入完整MixAuth页面，支持QQ/微信切换，必须签名验证',
            'dependency' => array('mixauth_qq_enable', '==', 'true'),
        ),
        array(
            'type' => 'submessage',
            'style' => 'info',
            'content' => '<h4><b>使用说明：</b></h4>
                <p>1. <strong>回调地址：</strong>' . home_url('/oauth/mixauthqq/callback') . '</p>
                <p>2. <strong>项目地址：</strong><a target="_blank" href="https://github.com/InvertGeek/mixauth">https://github.com/InvertGeek/mixauth</a></p>
                <p>3. <strong>功能特点：</strong>无需申请QQ互联应用，基于官方接口逆向实现</p>
                <p>4. <strong>安全提示：</strong>签名验证由MixAuth服务端自动处理，无需手动配置密钥</p>',
            'dependency' => array('mixauth_qq_enable', '==', 'true'),
        ),
    )
));

CSF::createSection($prefix, array(
    'id' => 'authorization',
    'title' => '授权管理',
    'icon' => 'fa fa-shield',
    'fields' => array(
        CFS_Module_ZibPlugin::aut(),
    )
));